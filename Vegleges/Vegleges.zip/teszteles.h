#ifndef TESZTELES_H
#define TESZTELES_H

/**
 * \file teszteles.h
 *
 * Tesztelésre szánt függvények headerjeit tartalmazza
 */


/// Függvény amely tartalmazza a teljes program teszteseit
/// A tesztesetek a gtest_lite segítségével vannak megvalósítva
void tesztekFuttatasa();

#endif